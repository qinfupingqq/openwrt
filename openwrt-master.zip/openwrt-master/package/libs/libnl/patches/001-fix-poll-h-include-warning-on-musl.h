diff --git a/include/netlink/netlink.h b/include/netlink/netlink.h
index 5f68548..3bf3ed5 100644
--- a/include/netlink/netlink.h
+++ b/include/netlink/netlink.h
@@ -16,7 +16,7 @@
 #include <stdint.h>
 #include <string.h>
 #include <stdlib.h>
-#include <sys/poll.h>
+#include <poll.h>
 #include <sys/socket.h>
 #include <sys/types.h>
 #include <sys/time.h>
